const ids = {
  dayPercent: document.querySelector("#dayPercent"),
  dayMoney: document.querySelector("#dayMoney"),
  weekPercent: document.querySelector("#weekPercent"),
  weekMoney: document.querySelector("#weekMoney"),
  monthPercent: document.querySelector("#monthPercent"),
  monthMoney: document.querySelector("#monthMoney"),
  history: document.querySelector("#history"),
  clearButton: document.querySelector("#clearButton")
};

function formatNTD(value) {
  return `NT$${Number(value || 0).toFixed(4)}`;
}

function averagePercent(items) {
  return items.length
    ? Math.round(items.reduce((sum, item) => sum + (item.savedPercent || 0), 0) / items.length)
    : 0;
}

function within(records, days) {
  const now = Date.now();
  const range = days * 24 * 60 * 60 * 1000;
  return records.filter(item => now - new Date(item.createdAt).getTime() <= range);
}

async function render() {
  const data = await chrome.storage.local.get("tokenMasterRecords");
  const records = Array.isArray(data.tokenMasterRecords) ? data.tokenMasterRecords : [];
  const day = within(records, 1);
  const week = within(records, 7);
  const month = within(records, 31);
  ids.dayPercent.textContent = `${averagePercent(day)}%`;
  ids.weekPercent.textContent = `${averagePercent(week)}%`;
  ids.monthPercent.textContent = `${averagePercent(month)}%`;
  ids.dayMoney.textContent = formatNTD(day.reduce((sum, item) => sum + (item.savedMoney || 0), 0));
  ids.weekMoney.textContent = formatNTD(week.reduce((sum, item) => sum + (item.savedMoney || 0), 0));
  ids.monthMoney.textContent = formatNTD(month.reduce((sum, item) => sum + (item.savedMoney || 0), 0));
  ids.history.innerHTML = records.length ? records.slice(0, 8).map(item => `
    <div class="item">
      <b>${item.tool} · 節省 ${item.savedPercent}% token</b><br>
      ${new Date(item.createdAt).toLocaleString("zh-TW")}<br>
      ${item.beforeTokens} → ${item.afterTokens} tokens，${formatNTD(item.savedMoney)}
    </div>
  `).join("") : `<div class="item">尚無使用紀錄。</div>`;
}

ids.clearButton.addEventListener("click", async () => {
  await chrome.storage.local.set({ tokenMasterRecords: [] });
  render();
});

render();
