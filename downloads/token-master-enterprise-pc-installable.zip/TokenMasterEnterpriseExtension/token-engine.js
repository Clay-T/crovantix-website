(function () {
  const rates = {
    ChatGPT: 0.09,
    Gemini: 0.07,
    Claude: 0.11,
    Perplexity: 0.08,
    Copilot: 0.08
  };

  function estimateTokens(text) {
    const normalized = String(text || "").trim();
    if (!normalized) return 0;
    const zh = (normalized.match(/[\u4e00-\u9fff]/g) || []).length;
    const words = normalized.replace(/[\u4e00-\u9fff]/g, " ").split(/\s+/).filter(Boolean).length;
    return Math.max(1, Math.ceil(zh * 0.85 + words * 1.35));
  }

  function optimizePrompt(text) {
    const original = String(text || "").trim();
    if (!original) return "";
    const cleaned = original
      .replace(/\s+/g, " ")
      .replace(/請問一下|我想要請你幫我|我想要你幫我|麻煩你可以幫我|麻煩你|可以幫我|請幫我|如果可以的話|拜託|謝謝/g, "")
      .replace(/\b(?:please|kindly)\b[,\s]*/gi, "")
      .replace(/\b(?:could you|can you|would you|will you)\s+(?:please\s+)?/gi, "")
      .replace(/\b(?:i would like you to|i want you to|i need you to|i need help to|i need help with|help me|help us)\s+/gi, "")
      .replace(/\b(?:can you help me|could you help me|please help me)\s+(?:to\s+|with\s+)?/gi, "")
      .replace(/\b(?:i am trying to|i'm trying to|i would like to|i want to)\s+/gi, "")
      .replace(/\b(?:if possible|when possible|thanks|thank you|many thanks|asap)\b[,\s]*/gi, "")
      .replace(/\b(?:in a clear and concise manner|in a concise way|as clearly as possible)\b/gi, "concisely")
      .replace(/\b(?:make sure to|be sure to|do not forget to)\s+/gi, "")
      .replace(/\b(?:provide me with|give me|show me)\s+/gi, "provide ")
      .replace(/\b(?:a detailed|a comprehensive|a complete)\s+(analysis|summary|plan|comparison|report|explanation)\b/gi, "$1")
      .replace(/\b(?:step by step|step-by-step)\b/gi, "steps")
      .replace(/\b(?:including but not limited to|including)\b/gi, "include")
      .replace(/\b(?:the following|below)\s+/gi, "")
      .replace(/\b(?:that is suitable for|that can be used for)\b/gi, "for")
      .replace(/\b(?:without changing the original meaning|while preserving the original meaning)\b/gi, "preserve meaning")
      .replace(/\b(?:keep|retain)\s+all\s+/gi, "preserve ")
      .replace(/\b(?:list out|write out)\b/gi, "list")
      .replace(/\b(?:summarize this into|summarize into)\b/gi, "summarize as")
      .replace(/\b(?:turn this into|convert this into)\b/gi, "convert to")
      .replace(/\b(?:for each item|for every item)\b/gi, "per item")
      .replace(/\b(?:pros and cons)\b/gi, "pros/cons")
      .replace(/\b(?:risks and assumptions)\b/gi, "risks/assumptions")
      .replace(/非常非常|真的真的/g, "非常")
      .replace(/完整回答/g, "回答")
      .replace(/避免冗長內容/g, "精簡")
      .replace(/不要太長/g, "精簡")
      .replace(/並依照使用者指定格式輸出/g, "依指定格式輸出")
      .replace(/內容要清楚、可執行/g, "清楚可執行")
      .replace(/請同時列出/g, "列出")
      .replace(/請提供/g, "提供")
      .replace(/請產生/g, "產生")
      .replace(/請用/g, "用")
      .replace(/請不要/g, "不要")
      .replace(/所有/g, "各")
      .replace(/可以直接/g, "可直接")
      .replace(/使用者容易理解/g, "易懂")
      .replace(/適合放在/g, "適用於")
      .replace(/包含/g, "含")
      .trim();
    const compact = cleaned
      .replace(/，/g, "；")
      .replace(/；+/g, "；")
      .replace(/\s+([.;,:!?])/g, "$1")
      .replace(/([.;,:!?]){2,}/g, "$1")
      .replace(/;\./g, ";")
      .replace(/(?:\.\s*){2,}$/g, ".")
      .replace(/^[；;,.，。\s]+/g, "")
      .replace(/[；。\s]+$/g, "")
      .trim();
    return estimateTokens(compact) < estimateTokens(original) && compact.replace(/[\s，。；、]/g, "").length >= 8
      ? compact
      : original;
  }

  function detectTool(hostname) {
    if (hostname.includes("gemini.google.com")) return "Gemini";
    if (hostname.includes("claude.ai")) return "Claude";
    if (hostname.includes("perplexity.ai")) return "Perplexity";
    if (hostname.includes("copilot.microsoft.com")) return "Copilot";
    return "ChatGPT";
  }

  function estimateSavedMoney(tool, savedTokens) {
    const rate = rates[tool] || 0.08;
    return Number(((savedTokens / 1000) * rate).toFixed(6));
  }

  function refine(text, tool) {
    const original = String(text || "");
    const optimized = optimizePrompt(original);
    const beforeTokens = estimateTokens(original);
    const afterTokens = estimateTokens(optimized);
    const savedTokens = Math.max(0, beforeTokens - afterTokens);
    const savedPercent = beforeTokens ? Math.max(0, Math.round((1 - afterTokens / beforeTokens) * 100)) : 0;
    const savedMoney = estimateSavedMoney(tool, savedTokens);
    return { original, optimized, beforeTokens, afterTokens, savedTokens, savedPercent, savedMoney };
  }

  window.TokenMasterEngine = { estimateTokens, optimizePrompt, detectTool, refine };
})();
