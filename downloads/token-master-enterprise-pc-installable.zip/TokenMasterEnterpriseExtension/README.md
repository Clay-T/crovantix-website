# Token大師 企業版 PC Browser Extension

這是 Token大師 企業版 PC 瀏覽器外掛安裝包，可搭配 macOS / Windows 桌面 App、企業級 API Gateway、SSO、稽核紀錄與團隊用量報表發布。IE 不支援 Chrome Extension Manifest V3，因此 IE 版本需使用 Windows 桌面常駐 Helper / IE 整合模組。

## 功能

- 支援 ChatGPT、Gemini、Claude、Perplexity、Copilot 網頁版與企業白名單 AI tool。
- 使用者在 AI tool 對話輸入框輸入 request 後，輸入框旁會出現「精簡」按鈕。
- 點選「精簡」後，外掛會在本機精簡目前輸入內容，並替換原本輸入文字。
- 使用者確認內容後，再自行按原 AI tool 的送出按鈕。
- Popup 可查看每日、每週、每月 token 節省百分比、估算省下 NT$、團隊用量與企業方案狀態。

## 安裝測試

1. 開啟 Chrome。
2. 前往 `chrome://extensions`。
3. 開啟「開發人員模式」。
4. 點選「載入未封裝項目」。
5. 選擇本資料夾：`TokenMasterEnterpriseExtension`。
6. 開啟 ChatGPT / Gemini / Claude 等網站。
7. 點選對話輸入框，旁邊會出現「精簡」按鈕。

## 正式產品建議

PC 正式版拆成兩種版本，兩種版本都支援 macOS 與 Windows，並支援 Chrome 與 IE。

| 版本 | macOS | Windows | Chrome | IE | 說明 |
| --- | --- | --- | --- | --- | --- |
| 一般使用者版 | 支援 | 支援 | Chrome Extension | Windows IE Helper | 本機精簡 prompt，不需 API Key。 |
| 企業版 | 支援 | 支援 | Chrome Extension | Windows IE Helper | 可加企業級 API Gateway，串接公司內部 AI 平台、SSO、稽核與用量報表。 |

## 建議交付項目

一般使用者版：

- macOS：`.dmg` 或 `.pkg` 安裝檔。
- Windows：`.exe` 或 `.msi` 安裝檔。
- Chrome Extension：用來在 AI tool 對話框旁顯示「精簡」按鈕。
- IE Helper：Windows 桌面常駐輔助程式 / IE 整合模組，用來支援 IE 對話框中的「精簡」按鈕。
- 本機 token 精簡引擎：prompt 不送到 Crovantix 後端。

企業版：

- macOS：企業安裝檔與 MDM 部署設定。
- Windows：企業安裝檔與 Intune / AD 部署設定。
- Chrome Extension：支援公司允許的 AI tool 網域。
- IE Helper：支援企業仍需使用 IE 的內部系統或 AI tool 頁面。
- 企業級 API Gateway：集中精簡、稽核、用量紀錄、部門報表與權限控管。
- SSO / 授權 token：供企業員工登入與控管。
