# Token大師 IE Helper

IE 不支援 Chrome Extension Manifest V3，因此 Token大師若要支援 IE，需要用 Windows 桌面常駐 Helper 或 IE Browser Helper Object（BHO）方式整合。

## 支援目標

- 支援 Windows 上的 Internet Explorer。
- 在 IE 的 AI tool 對話輸入框旁顯示「精簡」按鈕。
- 按下「精簡」後，以本機 Token大師精簡引擎處理目前輸入內容。
- 精簡後替換原本輸入內容，再由使用者自行送出。
- 每日 / 每週 / 每月 token 節省百分比與 NT$ 統計寫入本機資料庫或企業後台。

## 建議實作方式

一般使用者版：

- Windows tray app 常駐。
- 透過 Accessibility / UI Automation 偵測 IE 目前焦點輸入框。
- 顯示桌面浮動「精簡」按鈕。
- 本機精簡 prompt，不需 API Key。

企業版：

- IE BHO 或企業允許的桌面代理。
- 支援公司內部白名單網域。
- 可串接企業級 API Gateway、SSO、稽核紀錄與用量報表。
- 可由 IT 透過 Intune / AD / GPO 部署。

## 注意

IE 屬於舊式瀏覽器環境，正式版建議優先支援 Chrome；若企業仍需 IE，建議以 Windows 企業部署模式處理。
